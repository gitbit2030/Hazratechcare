@echo off
setlocal
title HazraTech - Printer Repair Tool
color 0A

:: ============================================================
:: HAZRATECH PRINTER REPAIR TOOL
:: Version 1.0
:: ============================================================

:: Check Administrator Privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Clear screen
cls

:: Header
powershell -NoProfile -Command ^
"Write-Host ''; Write-Host '==================================================' -ForegroundColor DarkGreen; Write-Host '                  HAZRATECH' -ForegroundColor Green; Write-Host '             PRINTER REPAIR TOOL' -ForegroundColor White; Write-Host '==================================================' -ForegroundColor DarkGreen; Write-Host ''"

:: Step 1
powershell -NoProfile -Command ^
"Write-Host '[1/3] ' -NoNewline -ForegroundColor Yellow; Write-Host 'Stopping Print Spooler...' -ForegroundColor White"

net stop spooler >nul 2>&1

:: Step 2
powershell -NoProfile -Command ^
"Write-Host '[2/3] ' -NoNewline -ForegroundColor Yellow; Write-Host 'Clearing stuck print jobs...' -ForegroundColor White"

del /Q /F "%windir%\System32\spool\PRINTERS\*.*" >nul 2>&1

:: Step 3
powershell -NoProfile -Command ^
"Write-Host '[3/3] ' -NoNewline -ForegroundColor Yellow; Write-Host 'Starting Print Spooler...' -ForegroundColor White"

net start spooler >nul 2>&1

:: Check status
sc query spooler | find /I "RUNNING" >nul

if %errorlevel%==0 (
    powershell -NoProfile -Command ^
    "Write-Host ''; Write-Host '==================================================' -ForegroundColor Green; Write-Host '        PRINTER REPAIR COMPLETED' -ForegroundColor Green; Write-Host '==================================================' -ForegroundColor Green; Write-Host ''; Write-Host '  Print queue cleared successfully.' -ForegroundColor White; Write-Host '  Print Spooler is running.' -ForegroundColor White; Write-Host ''; Write-Host '  HazraTech - Computer Service' -ForegroundColor Cyan; Write-Host ''"
) else (
    powershell -NoProfile -Command ^
    "Write-Host ''; Write-Host '==================================================' -ForegroundColor Red; Write-Host '        PRINTER REPAIR FAILED' -ForegroundColor Red; Write-Host '==================================================' -ForegroundColor Red; Write-Host ''; Write-Host '  Print Spooler could not be started.' -ForegroundColor White; Write-Host ''"
)

:: Greeting before closing
powershell -NoProfile -Command ^
"Write-Host ''; Write-Host '==================================================' -ForegroundColor DarkGreen; Write-Host '                    HAZRATECH' -ForegroundColor Green; Write-Host ''; Write-Host '          Thank you for choosing HazraTech' -ForegroundColor White; Write-Host '       Your trusted computer service partner' -ForegroundColor Cyan; Write-Host ''; Write-Host '              Closing in 3 seconds...' -ForegroundColor Yellow; Write-Host '==================================================' -ForegroundColor DarkGreen"

timeout /t 3 /nobreak >nul
exit /b